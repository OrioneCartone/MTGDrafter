import torch
import torch.nn as nn
import torch.nn.functional as F
import math

from src.utils.constants import (
    FEATURE_SIZE, MAX_POOL_SIZE, MAX_PACK_SIZE, 
    MODEL_EMBED_DIM, MODEL_HIDDEN_DIM
)
class AttentionAggregator(nn.Module):
    """Usa l'Attention per aggregare gli embedding del pool in modo contestuale."""
    def __init__(self, embed_dim: int):
        super().__init__()
        self.query_layer = nn.Linear(embed_dim, embed_dim, bias=False)
        self.key_layer = nn.Linear(embed_dim, embed_dim, bias=False)
        self.value_layer = nn.Linear(embed_dim, embed_dim, bias=False)
        self.scale = math.sqrt(embed_dim)

    def forward(self, query: torch.Tensor, context: torch.Tensor, context_mask: torch.Tensor) -> torch.Tensor:
        # --- GESTIONE DEL CASO DEL POOL VUOTO ---
        # Se tutte le posizioni del contesto sono mascherate, significa che il pool è vuoto.
        # In questo caso, restituiamo un vettore di zeri per evitare calcoli con -inf.
        if torch.all(context_mask):
            return torch.zeros_like(query)
        # --- FINE GESTIONE ---

        q = self.query_layer(query).unsqueeze(1)
        k = self.key_layer(context)
        v = self.value_layer(context)
        
        attention_scores = torch.bmm(q, k.transpose(1, 2)) / self.scale
        
        # --- AGGIUNTA DI STABILITÀ NUMERICA (OPZIONALE MA CONSIGLIATA) ---
        # Limitiamo i valori dei punteggi per evitare un'esplosione durante la softmax.
        attention_scores = torch.clamp(attention_scores, min=-10, max=10)
        
        # Applica la maschera
        attention_scores.masked_fill_(context_mask.unsqueeze(1), float('-inf'))
        
        # Applica softmax per ottenere i pesi di attenzione
        attention_weights = F.softmax(attention_scores, dim=-1)
        
        # Se per qualche motivo i pesi diventano NaN (dovuto a maschera completa), li azzeriamo.
        attention_weights = torch.nan_to_num(attention_weights, nan=0.0)
        
        # Calcola l'output come media pesata dei valori
        context_vector = torch.bmm(attention_weights, v).squeeze(1)
        return context_vector


class TransformerDrafter(nn.Module):
    def __init__(
        self,
        feature_size: int = FEATURE_SIZE,
        embed_dim: int = MODEL_EMBED_DIM,
        hidden_dim: int = MODEL_HIDDEN_DIM
        ):
        super().__init__()
        
        self.card_embedding_layer = nn.Sequential(
            nn.Linear(feature_size, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.ReLU()
        )
        
        self.aggregator = AttentionAggregator(embed_dim)
        
        self.pick_number_embedding = nn.Embedding(MAX_POOL_SIZE + 1, 16) 

        self.scorer = nn.Sequential(
            nn.Linear(embed_dim * 2 + 16, hidden_dim),
            nn.ReLU(),
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.LayerNorm(hidden_dim // 2),
            nn.Linear(hidden_dim // 2, 1)
        )

    def forward(self, pack: torch.Tensor, pool: torch.Tensor, pick_numbers: torch.Tensor) -> torch.Tensor:
        batch_size, pack_size, _ = pack.shape
        
        pack_embeds = self.card_embedding_layer(pack)
        pool_embeds = self.card_embedding_layer(pool)
        
        pool_mask = (pool.sum(dim=-1) == 0)
        pick_embed = self.pick_number_embedding(pick_numbers)

        all_scores = []
        for i in range(pack_size):
            pack_card_embed = pack_embeds[:, i, :]
            pool_context_vector = self.aggregator(pack_card_embed, pool_embeds, pool_mask)
            
            combined_vector = torch.cat([pack_card_embed, pool_context_vector, pick_embed], dim=1)
            
            score = self.scorer(combined_vector)
            all_scores.append(score)
            
        scores_tensor = torch.cat(all_scores, dim=1)
        return scores_tensor
