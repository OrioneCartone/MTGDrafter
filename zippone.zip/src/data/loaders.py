import json
from pathlib import Path
from typing import List, Dict, Tuple
import torch
from torch.utils.data import Dataset, DataLoader

from src.utils.constants import FEATURE_SIZE, MAX_PACK_SIZE, MAX_POOL_SIZE

def custom_collate_fn(batch: List[Tuple[Dict[str, torch.Tensor], torch.Tensor]]) -> Tuple[Dict[str, torch.Tensor], torch.Tensor]:
    """Funzione personalizzata per assemblare batch di dati con dimensioni variabili usando padding."""
    if not batch:
        return {}, torch.tensor([])
    
    # Inferisce dinamicamente la dimensione delle feature dal primo campione
    first_input, _ = batch[0]
    feature_size = first_input['pack'].shape[1] if first_input['pack'].numel() > 0 else FEATURE_SIZE

    batch_packs = torch.zeros(len(batch), MAX_PACK_SIZE, feature_size)
    batch_pools = torch.zeros(len(batch), MAX_POOL_SIZE, feature_size)
    batch_pick_numbers = []
    batch_targets = []

    for i, (model_input, target) in enumerate(batch):
        pack, pool = model_input['pack'], model_input['pool']
        
        if pack.numel() > 0: batch_packs[i, :pack.shape[0], :] = pack
        if pool.numel() > 0: batch_pools[i, :pool.shape[0], :] = pool
        
        batch_pick_numbers.append(model_input['pick_number'])
        batch_targets.append(target)
        
    collated_input = {
        'pack': batch_packs, 
        'pool': batch_pools,
        'pick_number': torch.stack(batch_pick_numbers)
    }
    collated_targets = torch.stack(batch_targets)
    
    return collated_input, collated_targets


class DraftLogDataset(Dataset):
    """Dataset PyTorch per caricare i log di draft."""
    def __init__(self, logs_dir: Path):
        self.log_files = sorted(list(logs_dir.glob("*.json")))
        if not self.log_files:
            raise FileNotFoundError(f"Nessun file di log trovato in {logs_dir}. Esegui 'generatelogs.py'.")
        print(f"Trovati {len(self.log_files)} campioni di log.")

    def __len__(self) -> int:
        return len(self.log_files)

    def __getitem__(self, idx: int) -> Tuple[Dict[str, torch.Tensor], torch.Tensor]:
        log_path = self.log_files[idx]
        with open(log_path, 'r') as f:
            log_data = json.load(f)
            
        pack_vectors = torch.tensor(log_data['pack_vectors'], dtype=torch.float32)
        pool_vectors = torch.tensor(log_data['pool_vectors'], dtype=torch.float32)
        choice_vector = torch.tensor(log_data['choice_vector'], dtype=torch.float32)
        
        pack_num = log_data.get('pack_num', 1)
        pick_num = log_data.get('pick_num', 1)
        absolute_pick_number = (pack_num - 1) * 15 + pick_num
        
        model_input = {
            'pack': pack_vectors,
            'pool': pool_vectors,
            'pick_number': torch.tensor(absolute_pick_number, dtype=torch.long)
        }
        
        equality_check = torch.all(pack_vectors == choice_vector, dim=1)
        choice_index = torch.where(equality_check)[0]
        
        target = choice_index[0].clone().detach().to(torch.long) if choice_index.numel() > 0 else torch.tensor(0, dtype=torch.long)
            
        return model_input, target
