import json
from pathlib import Path
from typing import List, Dict, Tuple
import torch
from torch.utils.data import Dataset, DataLoader

# Rimuoviamo la costante FEATURE_SIZE, la scopriremo dinamicamente

MAX_PACK_SIZE = 15
MAX_POOL_SIZE = 44

def custom_collate_fn(batch: List[Tuple[Dict[str, torch.Tensor], torch.Tensor]]) -> Tuple[Dict[str, torch.Tensor], torch.Tensor]:
    # --- MODIFICA CHIAVE: INFERIRE LA DIMENSIONE DELLE FEATURE ---
    # Prendiamo il primo campione per scoprire la dimensione delle feature
    # Questo rende il codice robusto a cambiamenti futuri
    if not batch:
        return {}, torch.tensor([])
    
    first_input, _ = batch[0]
    # Se il pack è vuoto, usa il pool. Se entrambi sono vuoti, default a 1.
    if first_input['pack'].numel() > 0:
        feature_size = first_input['pack'].shape[1]
    elif first_input['pool'].numel() > 0:
        feature_size = first_input['pool'].shape[1]
    else: # Caso raro di un log con pack e pool vuoti
        feature_size = 1 # Un default, anche se non dovrebbe accadere
    # --- FINE MODIFICA ---

    batch_packs = torch.zeros(len(batch), MAX_PACK_SIZE, feature_size)
    batch_pools = torch.zeros(len(batch), MAX_POOL_SIZE, feature_size)
    batch_targets = []

    for i, (model_input, target) in enumerate(batch):
        pack = model_input['pack']
        pool = model_input['pool']
        
        if pack.numel() > 0:
            batch_packs[i, :pack.shape[0], :] = pack
        if pool.numel() > 0:
            batch_pools[i, :pool.shape[0], :] = pool
        
        batch_targets.append(target)
        
    collated_input = {'pack': batch_packs, 'pool': batch_pools}
    collated_targets = torch.stack(batch_targets)
    
    return collated_input, collated_targets


class DraftLogDataset(Dataset):
    # ... (il codice di __init__, __len__ e __getitem__ rimane identico) ...
    def __init__(self, logs_dir: Path):
        super().__init__()
        self.logs_dir = logs_dir
        self.log_files = sorted(list(self.logs_dir.glob("*.json")))
        if not self.log_files:
            raise FileNotFoundError(f"Nessun file di log trovato in {logs_dir}. Esegui prima 'scripts/generate_logs.py'.")
        print(f"Trovati {len(self.log_files)} campioni di log.")

    def __len__(self) -> int:
        return len(self.log_files)

    def __getitem__(self, idx: int) -> Tuple[Dict[str, torch.Tensor], torch.Tensor]:
        log_path = self.log_files[idx]
        with open(log_path, 'r') as f:
            log_data = json.load(f)
            
        pack_vectors = torch.tensor(log_data['pack_vectors'], dtype=torch.float32)
        pool_vectors = torch.tensor(log_data['pool_vectors'], dtype=torch.float32)
        choice_vector = torch.tensor(log_data['choice_vector'], dtype=torch.float32)
        
        model_input = {'pack': pack_vectors, 'pool': pool_vectors}
        
        equality_check = torch.all(pack_vectors == choice_vector, dim=1)
        choice_index = torch.where(equality_check)[0]
        
        if choice_index.numel() == 0:
            # Aggiungiamo un print di debug per questi casi rari
            # print(f"Attenzione: la carta scelta non è stata trovata nel pack per il file {log_path.name}")
            target = torch.tensor(0, dtype=torch.long)
        else:
            # Usiamo .clone().detach() per evitare il warning
            target = choice_index[0].clone().detach().to(torch.long)
            
        return model_input, target


if __name__ == '__main__':
    # ... (il codice di test rimane uguale) ...
    PROJECT_ROOT = Path(__file__).parent.parent.parent
    LOGS_DIR = PROJECT_ROOT / "data" / "processed" / "draft_logs"
    
    dataset = DraftLogDataset(logs_dir=LOGS_DIR)
    data_loader = DataLoader(
        dataset, 
        batch_size=4, 
        shuffle=True, 
        collate_fn=custom_collate_fn
    )

    try:
        batch_input, batch_target = next(iter(data_loader))
        print("\n--- Esempio di un batch (con padding dinamico) ---")
        print("Forma del tensore 'pack' nel batch:", batch_input['pack'].shape)
        print("Forma del tensore 'pool' nel batch:", batch_input['pool'].shape)
        print("Indici delle scelte nel batch:", batch_target)
        print("✅ Test del DataLoader completato con successo!")
    except Exception as e:
        print(f"\n❌ Errore durante il test del DataLoader: {e}")



