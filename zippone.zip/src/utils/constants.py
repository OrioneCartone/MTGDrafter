# src/utils/constants.py

FEATURE_SIZE = 15
MAX_PACK_SIZE = 15
MAX_POOL_SIZE = 45 
