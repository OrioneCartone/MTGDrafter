from pathlib import Path
import sys
import json # Aggiunto per completezza, anche se non usato direttamente qui

# --- BLOCCO DI CODICE DA AGGIUNGERE ---
# Aggiunge la root del progetto al path di Python per trovare i nostri moduli
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.append(str(PROJECT_ROOT))
# --- FINE BLOCCO DA AGGIUNGERE ---

from src.data.collectors import download_scryfall_commons, download_cubecobra_list
from src.utils.constants import FEATURE_SIZE # Import non necessario qui, ma non fa male

# --- Configurazione ---
DATA_DIR = PROJECT_ROOT / "data"
SCRYFALL_OUTPUT_FILE = DATA_DIR / "external" / "scryfall_commons.json"
CUBE_LISTS_DIR = DATA_DIR / "raw" / "cube_lists"

def main():
    """Script per scaricare i dati necessari per l'ambiente Pauper Cube."""
    print("--- Avvio download dati (Focus: Pauper) ---")

    # 1. Scarica il database di TUTTE le carte comuni.
    download_scryfall_commons(output_path=SCRYFALL_OUTPUT_FILE)

    # 2. Scarica le liste dei cubi di sole comuni.
    pauper_cubes_to_download = [
        "thepaupercube",
        "mengupaupercube",
        "difinitivepauper",
        "gilpauper" 
    ]
    
    print("\n--- Download Liste Cubi Pauper ---")
    for cube_id in pauper_cubes_to_download:
        cube_output_path = CUBE_LISTS_DIR / f"{cube_id}.json"
        download_cubecobra_list(cube_id=cube_id, output_path=cube_output_path)

    print("\n--- Download completato. ---")

if __name__ == "__main__":
    main()
